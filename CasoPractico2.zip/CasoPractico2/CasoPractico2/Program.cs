﻿using System;

public delegate double CalcularSalario(double salarioBase);

public class Empleado
{
    public string Nombre { get; set; }
    public double SalarioBase { get; set; }

    public Empleado(string nombre, double salarioBase)
    {
        Nombre = nombre;
        SalarioBase = salarioBase;
    }

    public double CalcularSalarioTotal(CalcularSalario calcularSalario)
    {
        return calcularSalario(SalarioBase);
    }
}

class Program
{
    static void Main(string[] args)
    {
        Empleado tiempoCompleto = new Empleado("Juan Perez", 2000);
        Empleado tiempoParcial = new Empleado("María López", 1500);
        Empleado temporal = new Empleado("Carla Gomez", 1000);

        CalcularSalario salarioTiempoCompleto = (salarioBase) => salarioBase + salarioBase * 0.10;
        CalcularSalario salarioTiempoParcial = (salarioBase) => salarioBase;
        CalcularSalario salarioTemporal = (salarioBase) => salarioBase + salarioBase * 0.05;

        Console.WriteLine("Tiempo Completo - Juan Perez: " + tiempoCompleto.CalcularSalarioTotal(salarioTiempoCompleto));
        Console.WriteLine("Tiempo Parcial - María López: " + tiempoParcial.CalcularSalarioTotal(salarioTiempoParcial));
        Console.WriteLine("Temporal - Carla Gomez: " + temporal.CalcularSalarioTotal(salarioTemporal));
    }
}
